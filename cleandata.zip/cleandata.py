import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
# Load dataset
df = pd.read_csv("Age Prediction.csv")

# Remove duplicates
df.drop_duplicates(inplace=True)

# Handle missing values
df.fillna(df.median(numeric_only=True), inplace=True)  
df.fillna("Unknown", inplace=True)  

# Convert data types
df = df.convert_dtypes()  

# Save cleaned dataset
df.to_csv("cleaned_dataset.csv", index=False)

print("Data cleaning completed. Cleaned file saved as 'cleaned_dataset.csv'.")
import matplotlib.pyplot as plt 
plt.hist(df['Age'],bins = 30,color ="purple",edgecolor  = "black")
plt.xlabel('Age')
plt.ylabel("frequency")
plt.title('age distribution')
plt.show()
df = pd.read_csv('Age Prediction.csv')
data = df['Age'].value_counts()
plt.figure(figsize = (6,6))
plt.pie(data,labels=data.index,autopct = '%1.1f%%')
plt.savefig("pie_chart.png")
plt.show()
data = pd.read_csv('Age Prediction.csv')
sampled_data = data.head(50)
sns.boxplot(data = sampled_data, x = 'Age')
plt.show()
data = pd.read_csv('Age Prediction.csv')
sampled_data = data.head(50)
sns.scatterplot(data = sampled_data,x = 'Age',y = 'ID')
plt.show()
df= pd.read_csv('Age Prediction.csv')
continuous_features = df.select_dtypes(include=[np.number])
corr_matrix = continuous_features.corr()
plt.figure(figsize =(10,5))
sns.heatmap(corr_matrix,annot = True,cmap = "coolwarm",fmt=".2f",linewidths=0.5)
plt.title("Correlation matrix heatmap",fontsize=15)
plt.show()
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

# Load data
file_path = "Age Prediction.csv"
df = pd.read_csv(file_path)

# Handle missing values (choose one)
df.dropna(inplace=True)  # Option 1: Remove rows with NaN
# df.fillna(df.mean(), inplace=True)  # Option 2: Replace NaN with column mean

# Prepare data
X = df[['ID', 'Age', 'Gender']].values
y = df['Age_group'].values

test_size = 0.2
total_size = len(df)
test_size = int(total_size * test_size)

indices = np.random.permutation(total_size)
X_train, X_test = X[indices[:-test_size]], X[indices[-test_size:]]
Y_train, Y_test = y[indices[:-test_size]], y[indices[-test_size:]]

# Train the KNN model
model = KNeighborsClassifier(n_neighbors=3)
model.fit(X_train, Y_train)

# Predict and evaluate
y_pred = model.predict(X_test)
accuracy = np.sum(y_pred == Y_test) / len(Y_test)

print(f"Predictions: {y_pred}")
print(f"Actual labels: {Y_test}")
print(f"Accuracy: {accuracy*100:.2f}%")